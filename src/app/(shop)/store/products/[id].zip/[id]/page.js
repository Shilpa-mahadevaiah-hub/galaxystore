import { notFound } from "next/navigation";

export default async function ProductDetailsPage({ params }) {
  const { id } = await params;

  // Delay only to demonstrate loading.js
  await new Promise((resolve) => setTimeout(resolve, 2000));

  // Simulate an error
  if (id === "500") {
    throw new Error("Server error");
  }

  const response = await fetch(
    `http://localhost:3000/api/products/${id}`
  );

  if (response.status === 404) {
    notFound();
  }

  if (!response.ok) {
    throw new Error("Failed to fetch product");
  }

  const product = await response.json();

  return (
    <div>
      <h1>{product.name}</h1>
      <p>Price: ₹{product.price}</p>
    </div>
  );
}